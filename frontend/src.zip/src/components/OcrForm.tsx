"use client";
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";

export function OcrForm() {
  const [file, setFile] = useState<File | null>(null);
  const [ocrResult, setOcrResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);
    setError(null);
    setOcrResult(null);
    const formData = new FormData();
    formData.append("file", file);
    try {
      const res = await fetch("http://127.0.0.1:8000/ocr", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error("Failed to get OCR result");
      const data = await res.json();
      setOcrResult(data);
    } catch (err: any) {
      setError(err.message || "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">
          Extract Text from Image
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 items-center"
        >
          <Input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="w-full"
          />
          <Button type="submit" disabled={!file || loading} className="w-full">
            {loading ? "Processing..." : "Extract Text"}
          </Button>
        </form>
        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {loading && (
          <div className="mt-6">
            <Skeleton className="h-32 w-full rounded" />
            <Skeleton className="h-6 w-1/2 mt-2 rounded" />
          </div>
        )}
        {ocrResult && (
          <div className="mt-6">
            <h2 className="font-semibold mb-2">OCR Results</h2>
            <pre className="bg-gray-900 text-gray-100 rounded p-4 overflow-x-auto text-sm">
              {JSON.stringify(ocrResult, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
